# Handwerker Rechner Deutschland

Privater, offline nutzbarer Rechner für Handwerker. Kein Login, kein GPS,
keine Kontakte. Kundendaten werden nicht gespeichert. Keine Werbung in dieser Version.

## Funktionen

Rechner: Rohrinhalt, Rohrlänge & Gefälle, Isolierung, Heizkörper-Leistung, Druckverlust,
kW ↔ BTU/h, Liter ↔ m³, mm ↔ Zoll, Arbeitszeit & Lohn, MwSt.-Rechner.

PDF-Angebot (Tab "PDF"): Kundenname, Adresse, Projekt, Angebotsnummer (automatischer Zähler),
Datum, Arbeitskosten, Anfahrt, Materialkosten, MwSt. (oder Kleinunternehmer § 19 UStG),
Gesamtpreis. Das PDF wird lokal erzeugt und kann geteilt, gespeichert oder angezeigt werden.
Optional: eigene Firmendaten, nur lokal gespeichert.

Als "bald" markiert: Materialkosten (Artikelliste), Favoriten.

## Rechenregeln

- Angebote immer auf Netto-Basis: Positionen (auf Cent gerundet) addieren, einmal MwSt. aufschlagen.
- Druckverlust: Δp = (λ·L/d + Σζ)·ρ·v²/2, λ = 64/Re (laminar) bzw. Colebrook-White;
  Wasser-Stoffwerte nach IAPWS-IF97 (Tabelle in `lib/logic.dart`). Zwischen Re 2.300 und 4.000 weist die App auf Unsicherheit hin.
- Heizkörper-Leistung ist ein Richtwert (W/m², skaliert mit der Raumhöhe), keine Heizlastberechnung (DIN EN 12831).

## Formeln prüfen

```bash
pip install fluids iapws
python3 tools/verify_formulas.py           # unabhängige Prüfung gegen fluids/iapws
python3 tools/verify_formulas.py --dart    # erzeugt die Wasser-Tabelle als Dart-Code
flutter test                               # Dart-Tests (Referenzwerte aus dem Python-Skript)
```

## Starten und APK bauen

Voraussetzung: Flutter SDK (stable) und Android Studio.

```bash
flutter create --org de.deinname --project-name handwerker_rechner --platforms=android .
flutter pub get
flutter test
flutter run                      # auf Gerät oder Emulator
flutter build apk --release      # APK zum Testen
flutter build appbundle --release  # AAB für Google Play
```

Ohne lokale Installation: `.github/workflows/build-apk.yml` baut APK und AAB in GitHub Actions.
Weitere Schritte: `docs/GOOGLE_PLAY.md`.

## Struktur

- `lib/logic.dart`: Rechenfunktionen, Wasser-Tabelle, Formatierung
- `lib/calc_page.dart`: wiederverwendbare Rechner-Seite (Eingaben, Dropdown, Live-Ergebnis)
- `lib/calculators.dart`: Definition der Rechner
- `lib/angebot_page.dart`, `lib/pdf_angebot.dart`, `lib/storage.dart`: PDF-Angebot
- `lib/home_screen.dart`, `lib/welcome_screen.dart`, `lib/theme.dart`: Oberfläche
- `lib/legal_pages.dart`: Datenschutz/Impressum (Entwurf, Platzhalter ausfüllen)
- `tools/verify_formulas.py`: unabhängige Formelprüfung
- `assets/fonts/`: DejaVu Sans für das PDF (€, ä, ö, ü, ß); Lizenz liegt bei

## Noch offen

- Materialkosten (Artikelliste), Favoriten (lokal), Umschalter mm/Zoll
- Impressum und Datenschutz mit echten Angaben füllen (Platzhalter)
- AdMob mit Einwilligungsdialog (Google UMP) und Premium, erst nach den Tests
- App-Icon, Store-Listing, Signierung (siehe `docs/GOOGLE_PLAY.md`)
