import 'package:flutter/material.dart';

import 'angebot_page.dart';
import 'calculators.dart';
import 'legal_pages.dart';

/// Rahmen mit Navigation unten: Start, Favoriten, PDF, Mehr.
class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const HomeTab(),
      const PlaceholderTab(
        title: 'Favoriten',
        text: 'Hier erscheinen bald deine Lieblings-Rechner. '
            'Sie werden nur auf deinem Gerät gespeichert.',
      ),
      const AngebotPage(),
      const MoreTab(),
    ];
    return Scaffold(
      // IndexedStack erhält die Eingaben im Angebot beim Tab-Wechsel.
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Start'),
          NavigationDestination(icon: Icon(Icons.star), label: 'Favoriten'),
          NavigationDestination(icon: Icon(Icons.description), label: 'PDF'),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'Mehr'),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(
      children: [
        Container(
          width: double.infinity,
          color: scheme.primary,
          padding: EdgeInsets.fromLTRB(
            20,
            MediaQuery.of(context).padding.top + 16,
            20,
            20,
          ),
          child: Row(
            children: [
              Icon(Icons.home_repair_service, size: 38, color: scheme.onPrimary),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Handwerker Rechner',
                    style: TextStyle(
                      color: scheme.onPrimary,
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    'Deutschland',
                    style: TextStyle(color: scheme.onPrimary, fontSize: 15),
                  ),
                ],
              ),
            ],
          ),
        ),
        Expanded(
          child: GridView.count(
            crossAxisCount: 2,
            padding: const EdgeInsets.all(16),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.15,
            children: [for (final c in calculators) _CalcTile(def: c)],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: Text(
            'Alle Berechnungen sind Richtwerte ohne Gewähr. '
            'Die App speichert keine Kundendaten und benötigt kein Konto.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ],
    );
  }
}

class _CalcTile extends StatelessWidget {
  const _CalcTile({required this.def});

  final CalcDef def;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final builder = def.builder;
    final enabled = builder != null;
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          if (builder == null) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('${def.label}: kommt bald')),
            );
            return;
          }
          Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => builder()),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                def.icon,
                size: 44,
                color: enabled ? scheme.primary : Colors.grey,
              ),
              const SizedBox(height: 8),
              Text(
                def.label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: enabled ? null : Colors.grey,
                ),
              ),
              if (!enabled)
                const Text('bald', style: TextStyle(color: Colors.grey, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

class PlaceholderTab extends StatelessWidget {
  const PlaceholderTab({super.key, required this.title, required this.text});

  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 18),
          ),
        ),
      ),
    );
  }
}

class MoreTab extends StatelessWidget {
  const MoreTab({super.key});

  @override
  Widget build(BuildContext context) {
    void oeffne(String titel, String text) => Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => LegalPage(title: titel, text: text),
          ),
        );
    void bald(String was) => ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('$was: kommt bald')));

    return Scaffold(
      appBar: AppBar(title: const Text('Mehr')),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.shield),
            title: const Text('Datenschutz'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => oeffne('Datenschutz', kDatenschutzText),
          ),
          ListTile(
            leading: const Icon(Icons.info),
            title: const Text('Impressum'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => oeffne('Impressum', kImpressumText),
          ),
          ListTile(
            leading: const Icon(Icons.workspace_premium),
            title: const Text('Werbung entfernen (Premium)'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => bald('Premium'),
          ),
          ListTile(
            leading: const Icon(Icons.star),
            title: const Text('App bewerten'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => bald('Bewertung'),
          ),
        ],
      ),
    );
  }
}
