import 'package:flutter/material.dart';

import 'theme.dart';
import 'welcome_screen.dart';

void main() {
  runApp(const HandwerkerRechnerApp());
}

class HandwerkerRechnerApp extends StatelessWidget {
  const HandwerkerRechnerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Handwerker Rechner',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const WelcomeScreen(),
    );
  }
}
