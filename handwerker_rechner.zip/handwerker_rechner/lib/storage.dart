import 'package:shared_preferences/shared_preferences.dart';

import 'pdf_angebot.dart';

/// Lokale Ablage auf dem Gerät (nichts verlässt das Telefon).
/// Gespeichert werden nur: eigene Firmendaten (optional) und der Angebotszähler.
class AngebotStorage {
  static const _kName = 'absender_name';
  static const _kAdresse = 'absender_adresse';
  static const _kUstId = 'absender_ust_id';

  static Future<Absender> ladeAbsender() async {
    final p = await SharedPreferences.getInstance();
    return Absender(
      name: p.getString(_kName) ?? '',
      adresse: p.getString(_kAdresse) ?? '',
      ustId: p.getString(_kUstId) ?? '',
    );
  }

  static Future<void> speichereAbsender(Absender a) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kName, a.name);
    await p.setString(_kAdresse, a.adresse);
    await p.setString(_kUstId, a.ustId);
  }

  /// Nächste freie Laufnummer für das Jahr (ohne sie zu verbrauchen).
  static Future<int> naechsteLaufnummer(int jahr) async {
    final p = await SharedPreferences.getInstance();
    return (p.getInt('zaehler_$jahr') ?? 0) + 1;
  }

  /// Markiert die Laufnummer als vergeben.
  static Future<void> laufnummerVergeben(int jahr, int nummer) async {
    final p = await SharedPreferences.getInstance();
    final aktuell = p.getInt('zaehler_$jahr') ?? 0;
    if (nummer > aktuell) await p.setInt('zaehler_$jahr', nummer);
  }
}
