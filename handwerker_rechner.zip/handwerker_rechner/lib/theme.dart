import 'package:flutter/material.dart';

const Color kBrandBlue = Color(0xFF0B4A9F);

/// Hoher Kontrast, große Schrift und große Touch-Flächen:
/// gedacht für die Baustelle (Sonnenlicht, Handschuhe, schnelle Eingabe).
ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: kBrandBlue,
    brightness: Brightness.light,
  ).copyWith(primary: kBrandBlue, onPrimary: Colors.white);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: const Color(0xFFEFF3F8),
    appBarTheme: AppBarTheme(
      backgroundColor: scheme.primary,
      foregroundColor: scheme.onPrimary,
      titleTextStyle: TextStyle(
        color: scheme.onPrimary,
        fontSize: 22,
        fontWeight: FontWeight.w600,
      ),
    ),
  );
}
